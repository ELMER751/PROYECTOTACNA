<?php

declare(strict_types=1);

namespace Greenter\Services;

use LogicException;

class InvalidServiceResponseException extends LogicException
{
}