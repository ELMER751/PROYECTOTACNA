<?php

namespace PHPSTORM_META;

override(\Greenter\Ws\Builder\ServiceBuilder::build(0), type(0));