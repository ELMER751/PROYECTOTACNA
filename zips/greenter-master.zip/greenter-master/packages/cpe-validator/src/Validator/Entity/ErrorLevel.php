<?php

declare(strict_types=1);

namespace Greenter\Validator\Entity;

class ErrorLevel
{
    public const EXCEPTION = '1';
    public const OBSERVATION = '2';
}
