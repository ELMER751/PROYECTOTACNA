<?php

declare(strict_types=1);

namespace Greenter\Report\Resolver;

use LogicException;

class InvalidDocumentException extends LogicException
{

}